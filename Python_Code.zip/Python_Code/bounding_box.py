### BBOX on Test Images ###
import cv2,os,json
from google.colab.patches import cv2_imshow

color=(0,0,255)
thickness=1
for files in os.listdir('/content/output/'):
  with open("/content/output/"+files, 'r') as f:
    test_json = json.load(f)
  if len(test_json) == 0:
    continue
  else:
    print(test_json[0]['image'])
    path=test_json[0]['image']
    img=cv2.imread(path)
    for i in range(0,len(test_json)):
      a=test_json[i]['predictions']['bbox']
      start=(int(a[0]),int(a[1]))
      end=(int(a[2]),int(a[3]))
      x=int(a[0])
      y=int(a[1])-1
      predictedimg=cv2.rectangle(img,start,end,color,thickness)
      predictedimg=cv2.putText(predictedimg,'Pothole:'+test_json[i]['predictions']['score'],(x,y),cv2.FONT_HERSHEY_PLAIN,1,color,1,cv2.LINE_AA)
    cv2_imshow(predictedimg)
    savepath = path.split('.')[0].split('/')[len((path.split('.')[0].split('/')))-1]+".jpg"
    savepath = "/content/predictions/"+savepath
    cv2.imwrite(savepath, predictedimg)